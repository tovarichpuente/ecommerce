package interfaz;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.TitledBorder;
public class PanelBotones extends JPanel {
    private Ventana ventana;
    private JButton btnOpcion1;
    private JButton btnOpcion2;
    public PanelBotones(Ventana ventana) {
        this.ventana=ventana;
        setBorder(new TitledBorder("Opciones"));
        setLayout(new GridLayout(1,2));
        
        btnOpcion1=new JButton("Opción 1");
        add(btnOpcion1);
        
        btnOpcion2=new JButton("Opción 2");
        add(btnOpcion2);
    }
}
