package interfaz;
public class Inicio {
    public static void main(String[] args) {
        Ventana v=new Ventana();
        v.setVisible(true);
    }
    
}
