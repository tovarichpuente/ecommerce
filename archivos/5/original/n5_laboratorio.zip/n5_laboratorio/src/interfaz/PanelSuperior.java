package interfaz;
import java.awt.*;
import javax.swing.*;
public class PanelSuperior extends JPanel{
    private Ventana ventana;
    private JLabel labelPrueba;
    private JTextField textPrueba;
    public PanelSuperior(Ventana ventana) {
        this.ventana=ventana;
        labelPrueba=new JLabel("Programación");
        add(labelPrueba);
        textPrueba=new JTextField(10);
        add(textPrueba);
    }
}
