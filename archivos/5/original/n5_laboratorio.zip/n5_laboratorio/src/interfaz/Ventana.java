package interfaz;
import java.awt.*;
import javax.swing.*;
public class Ventana extends JFrame {
    private final PanelBotones panelBotones;
    private final PanelSuperior panelSuperior;
    public Ventana() {
        setSize(400, 200);
        setTitle("Mi ventana");
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        getContentPane().setLayout(new BorderLayout());
        panelBotones=new PanelBotones(this);
        getContentPane().add(panelBotones, BorderLayout.SOUTH);
        
        panelSuperior=new PanelSuperior(this);
        getContentPane().add(panelSuperior, BorderLayout.NORTH);
    }
}
